﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class mainWindow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btn_convert = New System.Windows.Forms.Button()
        Me.txtbox_amount = New System.Windows.Forms.TextBox()
        Me.txtbox_rate = New System.Windows.Forms.TextBox()
        Me.lbl_amount = New System.Windows.Forms.Label()
        Me.lbl_rate = New System.Windows.Forms.Label()
        Me.lbl_output = New System.Windows.Forms.Label()
        Me.cmbbox_convertTo = New System.Windows.Forms.ComboBox()
        Me.lbl_currencySelect = New System.Windows.Forms.Label()
        Me.lbl_amountCurrencySymbol = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_convert
        '
        Me.btn_convert.Location = New System.Drawing.Point(82, 226)
        Me.btn_convert.Name = "btn_convert"
        Me.btn_convert.Size = New System.Drawing.Size(68, 23)
        Me.btn_convert.TabIndex = 0
        Me.btn_convert.Text = "Convert"
        Me.btn_convert.UseVisualStyleBackColor = True
        '
        'txtbox_amount
        '
        Me.txtbox_amount.Location = New System.Drawing.Point(66, 60)
        Me.txtbox_amount.Name = "txtbox_amount"
        Me.txtbox_amount.Size = New System.Drawing.Size(100, 20)
        Me.txtbox_amount.TabIndex = 1
        '
        'txtbox_rate
        '
        Me.txtbox_rate.Location = New System.Drawing.Point(67, 172)
        Me.txtbox_rate.Name = "txtbox_rate"
        Me.txtbox_rate.Size = New System.Drawing.Size(100, 20)
        Me.txtbox_rate.TabIndex = 2
        Me.txtbox_rate.Visible = False
        '
        'lbl_amount
        '
        Me.lbl_amount.AutoSize = True
        Me.lbl_amount.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_amount.ForeColor = System.Drawing.Color.White
        Me.lbl_amount.Location = New System.Drawing.Point(81, 36)
        Me.lbl_amount.Name = "lbl_amount"
        Me.lbl_amount.Size = New System.Drawing.Size(72, 21)
        Me.lbl_amount.TabIndex = 3
        Me.lbl_amount.Text = "Amount"
        '
        'lbl_rate
        '
        Me.lbl_rate.AutoSize = True
        Me.lbl_rate.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_rate.ForeColor = System.Drawing.Color.White
        Me.lbl_rate.Location = New System.Drawing.Point(94, 148)
        Me.lbl_rate.Name = "lbl_rate"
        Me.lbl_rate.Size = New System.Drawing.Size(44, 21)
        Me.lbl_rate.TabIndex = 4
        Me.lbl_rate.Text = "Rate"
        Me.lbl_rate.Visible = False
        '
        'lbl_output
        '
        Me.lbl_output.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_output.ForeColor = System.Drawing.Color.White
        Me.lbl_output.Location = New System.Drawing.Point(2, 204)
        Me.lbl_output.Name = "lbl_output"
        Me.lbl_output.Size = New System.Drawing.Size(231, 21)
        Me.lbl_output.TabIndex = 5
        Me.lbl_output.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmbbox_convertTo
        '
        Me.cmbbox_convertTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbbox_convertTo.FormattingEnabled = True
        Me.cmbbox_convertTo.Items.AddRange(New Object() {"USD - US Dollars", "EUR - Euros", "JPY - Japanese Yen", "AUD - Australian Dollar", "CAD - Canadian Dollar", "Custom"})
        Me.cmbbox_convertTo.Location = New System.Drawing.Point(47, 120)
        Me.cmbbox_convertTo.Name = "cmbbox_convertTo"
        Me.cmbbox_convertTo.Size = New System.Drawing.Size(138, 21)
        Me.cmbbox_convertTo.TabIndex = 6
        '
        'lbl_currencySelect
        '
        Me.lbl_currencySelect.AutoSize = True
        Me.lbl_currencySelect.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_currencySelect.ForeColor = System.Drawing.Color.White
        Me.lbl_currencySelect.Location = New System.Drawing.Point(70, 96)
        Me.lbl_currencySelect.Name = "lbl_currencySelect"
        Me.lbl_currencySelect.Size = New System.Drawing.Size(92, 21)
        Me.lbl_currencySelect.TabIndex = 7
        Me.lbl_currencySelect.Text = "Convert To"
        '
        'lbl_amountCurrencySymbol
        '
        Me.lbl_amountCurrencySymbol.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_amountCurrencySymbol.ForeColor = System.Drawing.Color.White
        Me.lbl_amountCurrencySymbol.Location = New System.Drawing.Point(51, 59)
        Me.lbl_amountCurrencySymbol.Margin = New System.Windows.Forms.Padding(0)
        Me.lbl_amountCurrencySymbol.Name = "lbl_amountCurrencySymbol"
        Me.lbl_amountCurrencySymbol.Size = New System.Drawing.Size(15, 21)
        Me.lbl_amountCurrencySymbol.TabIndex = 8
        Me.lbl_amountCurrencySymbol.Text = "£"
        '
        'mainWindow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(234, 261)
        Me.Controls.Add(Me.lbl_amountCurrencySymbol)
        Me.Controls.Add(Me.lbl_currencySelect)
        Me.Controls.Add(Me.cmbbox_convertTo)
        Me.Controls.Add(Me.lbl_output)
        Me.Controls.Add(Me.lbl_rate)
        Me.Controls.Add(Me.lbl_amount)
        Me.Controls.Add(Me.txtbox_rate)
        Me.Controls.Add(Me.txtbox_amount)
        Me.Controls.Add(Me.btn_convert)
        Me.Name = "mainWindow"
        Me.Text = "Currency Converter"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_convert As Button
    Friend WithEvents txtbox_amount As TextBox
    Friend WithEvents txtbox_rate As TextBox
    Friend WithEvents lbl_amount As Label
    Friend WithEvents lbl_rate As Label
    Friend WithEvents lbl_output As Label
    Friend WithEvents cmbbox_convertTo As ComboBox
    Friend WithEvents lbl_currencySelect As Label
    Friend WithEvents lbl_amountCurrencySymbol As Label
End Class
