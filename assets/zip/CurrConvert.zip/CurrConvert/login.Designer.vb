﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.txtbox_username = New System.Windows.Forms.TextBox()
        Me.lbl_username = New System.Windows.Forms.Label()
        Me.lbl_password = New System.Windows.Forms.Label()
        Me.txtbox_password = New System.Windows.Forms.TextBox()
        Me.lbl_passwdIncorrect = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn_login
        '
        Me.btn_login.Location = New System.Drawing.Point(69, 190)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(75, 23)
        Me.btn_login.TabIndex = 0
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = True
        '
        'txtbox_username
        '
        Me.txtbox_username.Location = New System.Drawing.Point(58, 72)
        Me.txtbox_username.Name = "txtbox_username"
        Me.txtbox_username.Size = New System.Drawing.Size(100, 20)
        Me.txtbox_username.TabIndex = 1
        '
        'lbl_username
        '
        Me.lbl_username.AutoSize = True
        Me.lbl_username.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_username.ForeColor = System.Drawing.Color.White
        Me.lbl_username.Location = New System.Drawing.Point(65, 48)
        Me.lbl_username.Name = "lbl_username"
        Me.lbl_username.Size = New System.Drawing.Size(87, 21)
        Me.lbl_username.TabIndex = 2
        Me.lbl_username.Text = "Username"
        '
        'lbl_password
        '
        Me.lbl_password.AutoSize = True
        Me.lbl_password.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_password.ForeColor = System.Drawing.Color.White
        Me.lbl_password.Location = New System.Drawing.Point(66, 113)
        Me.lbl_password.Name = "lbl_password"
        Me.lbl_password.Size = New System.Drawing.Size(82, 21)
        Me.lbl_password.TabIndex = 4
        Me.lbl_password.Text = "Password"
        '
        'txtbox_password
        '
        Me.txtbox_password.Location = New System.Drawing.Point(57, 137)
        Me.txtbox_password.Name = "txtbox_password"
        Me.txtbox_password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(9679)
        Me.txtbox_password.Size = New System.Drawing.Size(100, 20)
        Me.txtbox_password.TabIndex = 3
        Me.txtbox_password.UseSystemPasswordChar = True
        '
        'lbl_passwdIncorrect
        '
        Me.lbl_passwdIncorrect.AutoSize = True
        Me.lbl_passwdIncorrect.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_passwdIncorrect.ForeColor = System.Drawing.Color.IndianRed
        Me.lbl_passwdIncorrect.Location = New System.Drawing.Point(13, 165)
        Me.lbl_passwdIncorrect.Name = "lbl_passwdIncorrect"
        Me.lbl_passwdIncorrect.Size = New System.Drawing.Size(191, 17)
        Me.lbl_passwdIncorrect.TabIndex = 5
        Me.lbl_passwdIncorrect.Text = "Username/Password Incorrect"
        Me.lbl_passwdIncorrect.Visible = False
        '
        'login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer), CType(CType(63, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(214, 251)
        Me.Controls.Add(Me.lbl_passwdIncorrect)
        Me.Controls.Add(Me.lbl_password)
        Me.Controls.Add(Me.txtbox_password)
        Me.Controls.Add(Me.lbl_username)
        Me.Controls.Add(Me.txtbox_username)
        Me.Controls.Add(Me.btn_login)
        Me.Name = "login"
        Me.Text = "Login"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn_login As Button
    Friend WithEvents txtbox_username As TextBox
    Friend WithEvents lbl_username As Label
    Friend WithEvents lbl_password As Label
    Friend WithEvents txtbox_password As TextBox
    Friend WithEvents lbl_passwdIncorrect As Label
End Class
