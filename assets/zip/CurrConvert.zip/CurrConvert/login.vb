﻿Public Class login
    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        'i thought about doing passwords properly with aes encryption and salting n stuff but i think thats overachieving a bit
        'also i dont wanna write like 3 functions and bugtest it and make sure it all works perfectly for nothing
        If txtbox_username.Text = "defaultuser0" And txtbox_password.Text = "password" Then 'If login correct, show converter and close login
            mainWindow.Show()
            Me.Close() 'For reference, to make this work I had to do Project -> Properties then set "Shutdown mode" to "When last form closes"
        Else
            lbl_passwdIncorrect.Visible = True 'preset label saying "password incorrect", looks better than just using a msgbox
        End If
    End Sub
End Class