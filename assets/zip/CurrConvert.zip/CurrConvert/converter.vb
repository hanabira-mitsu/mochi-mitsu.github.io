﻿Imports System.Text.RegularExpressions

Public Class mainWindow
    Public outputCurrency As String 'Public variable, allows for modification and use by multiple functions
    Private Sub btn_convert_Click(sender As Object, e As EventArgs) Handles btn_convert.Click
        Dim inputAmount As Decimal 'Create variables
        Dim convertRate As Decimal
        Dim outputAmount As Decimal
        If errorHandler() = True Then 'Don't run if error
            Return
        End If
        inputAmount = CDec(txtbox_amount.Text) 'Convert inputs to Decimal and store it
        convertRate = CDec(txtbox_rate.Text)
        outputAmount = Decimal.Round(inputAmount * convertRate, 2) 'Do the currency conversion, round output to 2 decimal places
        lbl_output.Text = outputCurrency & outputAmount 'Display output on label
    End Sub

    Private Function errorHandler() 'I know about try catch finally but this works better here
        If txtbox_amount.Text = "" Or txtbox_rate.Text = "" Then ' Info missing, throw error
            MsgBox("Amount and rate can't be empty!", MsgBoxStyle.Critical, "Error")
            Return True
        End If
        If Not Regex.IsMatch(txtbox_amount.Text, "[0-9.]") Or Not Regex.IsMatch(txtbox_rate.Text, "[0-9.]") Then 'Info incorrect, throw error
            MsgBox("Amount and rate must both be numbers!", MsgBoxStyle.Critical, "Error")
            Return True
        End If
        Return False 'No error, allow program to run
    End Function

    Private Sub cmbbox_convertTo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbbox_convertTo.SelectedIndexChanged
        If cmbbox_convertTo.SelectedItem = "Custom" Then 'If combobox set to custom, show rate input box and label for it
            txtbox_rate.Visible = True
            lbl_rate.Visible = True
        Else 'Combobox not set to custom, hide rate box and label
            txtbox_rate.Visible = False
            lbl_rate.Visible = False
        End If
        Select Case cmbbox_convertTo.SelectedItem 'Set currency symbol label and exchange rate according to selected currency
            Case "USD - US Dollars"
                outputCurrency = "$"
                txtbox_rate.Text = "1.2696"
            Case "EUR - Euros"
                outputCurrency = "€"
                txtbox_rate.Text = "1.1694"
            Case "JPY - Japanese Yen"
                outputCurrency = "¥"
                txtbox_rate.Text = "191.2935"
            Case "AUD - Australian Dollar"
                outputCurrency = "$"
                txtbox_rate.Text = "1.9369"
            Case "CAD - Canadian Dollar"
                outputCurrency = "$"
                txtbox_rate.Text = "1.7142"
            Case Else
                outputCurrency = ""
                txtbox_rate.Text = ""
        End Select
    End Sub
End Class